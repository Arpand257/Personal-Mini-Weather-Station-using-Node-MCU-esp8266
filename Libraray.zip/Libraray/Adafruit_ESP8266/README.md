# Adafruit_ESP8266 [![Build Status](https://github.com/adafruit/Adafruit_ESP8266/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_ESP8266/actions)

Example code for ESP8266 chipset
